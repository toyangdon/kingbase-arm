-- complain if script is sourced in ksql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION kdb_tinyint" to load this file. \quit

set search_path to sys_catalog, public;

------------------------------------------------------------------------------------
---------------------------conversion functions support-----------------------------
------------------------------------------------------------------------------------
-- char_to_tinyint
CREATE INTERNAL FUNCTION sys_catalog.TO_CHAR(tinyint)
RETURNS text
AS 'select cast($1 as text)'
LANGUAGE SQL
IMMUTABLE
PARALLEL SAFE
STRICT;

COMMENT ON INTERNAL FUNCTION sys_catalog.TO_CHAR(tinyint) IS 'convert tinyint to text';

-- tinyint_to_char
CREATE INTERNAL FUNCTION sys_catalog.TO_CHAR(tinyint, text)
RETURNS text
AS 'MODULE_PATHNAME','tinyint_to_char'
LANGUAGE C
STABLE
PARALLEL SAFE
STRICT;

COMMENT ON FUNCTION sys_catalog.TO_CHAR(tinyint, text) IS 'format tinyint to text';

-- tinyint <--> bool
CREATE INTERNAL FUNCTION sys_catalog.TINYINT(bool)
RETURNS tinyint
AS 'MODULE_PATHNAME','bool_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.BOOL(tinyint)
RETURNS bool
AS 'MODULE_PATHNAME','tinyint_bool'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- tinyint <--> int2
CREATE INTERNAL FUNCTION sys_catalog.TINYINT(int2)
RETURNS tinyint
AS 'MODULE_PATHNAME','int2_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.INT2(TINYINT)
RETURNS int2
AS 'MODULE_PATHNAME','tinyint_int2'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- tinyint <--> int4
CREATE INTERNAL FUNCTION sys_catalog.TINYINT(INT4)
RETURNS tinyint
AS 'MODULE_PATHNAME','int4_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.INT4(TINYINT)
RETURNS int4
AS 'MODULE_PATHNAME','tinyint_int4'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- tinyint <--> int8
CREATE INTERNAL FUNCTION sys_catalog.TINYINT(INT8)
RETURNS tinyint
AS 'MODULE_PATHNAME','int8_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.INT8(TINYINT)
RETURNS int8
AS 'MODULE_PATHNAME','tinyint_int8'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- tinyint <--> float4
CREATE INTERNAL FUNCTION sys_catalog.TINYINT(FLOAT4)
RETURNS tinyint
AS 'MODULE_PATHNAME','float4_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.FLOAT4(TINYINT)
RETURNS float4
AS 'MODULE_PATHNAME','tinyint_float4'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- tinyint <--> float8
CREATE INTERNAL FUNCTION sys_catalog.TINYINT(FLOAT8)
RETURNS tinyint
AS 'MODULE_PATHNAME','float8_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.FLOAT8(TINYINT)
RETURNS float8
AS 'MODULE_PATHNAME','tinyint_float8'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- tinyint <--> numeric
CREATE INTERNAL FUNCTION sys_catalog.TINYINT(NUMERIC)
RETURNS tinyint
AS 'MODULE_PATHNAME','numeric_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.TINYINTTONUMERIC(TINYINT)
RETURNS numeric
AS 'MODULE_PATHNAME','tinyint_numeric'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- tinyint <--> bpchar varchar text
CREATE INTERNAL FUNCTION sys_catalog.TINYINT(BPCHAR)
RETURNS tinyint
AS 'MODULE_PATHNAME','bpchar_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.TINYINT(VARCHAR)
RETURNS tinyint
AS 'MODULE_PATHNAME','varchar_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.TINYINT(TEXT)
RETURNS tinyint
AS 'MODULE_PATHNAME','text_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.TEXT(TINYINT)
RETURNS text
AS 'MODULE_PATHNAME','tinyint_text'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- CREATE CAST
CREATE CAST (int4 AS tinyint) WITH FUNCTION TINYINT(INT4) AS ASSIGNMENT;
CREATE CAST (tinyint AS int4) WITH FUNCTION INT4(TINYINT) AS IMPLICIT;
CREATE CAST (bool AS tinyint) WITH FUNCTION TINYINT(BOOL) AS ASSIGNMENT;
CREATE CAST (tinyint AS bool) WITH FUNCTION BOOL(TINYINT) AS ASSIGNMENT;
CREATE CAST (int2 AS tinyint) WITH FUNCTION TINYINT(INT2) AS ASSIGNMENT;
CREATE CAST (tinyint AS int2) WITH FUNCTION INT2(TINYINT) AS IMPLICIT;
CREATE CAST (int8 AS tinyint) WITH FUNCTION TINYINT(INT8) AS ASSIGNMENT;
CREATE CAST (tinyint AS int8) WITH FUNCTION INT8(TINYINT) AS IMPLICIT;
CREATE CAST (float4 AS tinyint) WITH FUNCTION TINYINT(FLOAT4) AS ASSIGNMENT;
CREATE CAST (tinyint AS float4) WITH FUNCTION FLOAT4(tinyint) AS IMPLICIT;
CREATE CAST (float8 AS tinyint) WITH FUNCTION TINYINT(float8) AS ASSIGNMENT;
CREATE CAST (tinyint AS float8) WITH FUNCTION FLOAT8(tinyint) AS IMPLICIT;
CREATE CAST (numeric AS tinyint) WITH FUNCTION TINYINT(numeric) AS ASSIGNMENT;
CREATE CAST (tinyint AS numeric) WITH FUNCTION TINYINTTONUMERIC(tinyint) AS IMPLICIT;
CREATE CAST (bpchar AS tinyint) WITH FUNCTION TINYINT(bpchar) AS IMPLICIT;
CREATE CAST (tinyint AS bpchar) WITH FUNCTION TEXT(tinyint) AS ASSIGNMENT;
CREATE CAST (varchar AS tinyint) WITH FUNCTION TINYINT(varchar) AS IMPLICIT;
CREATE CAST (tinyint AS varchar) WITH FUNCTION TEXT(tinyint) AS ASSIGNMENT;
CREATE CAST (text AS tinyint) WITH FUNCTION TINYINT(text) AS IMPLICIT;
CREATE CAST (tinyint AS text) WITH FUNCTION TEXT(tinyint) AS IMPLICIT;

-- accum
CREATE INTERNAL FUNCTION sys_catalog.TINYINT_ACCUM(internal, tinyint)
RETURNS internal
AS 'MODULE_PATHNAME','tinyint_accum'
LANGUAGE C
PARALLEL SAFE
IMMUTABLE;

------------------------------------------------------------------------------------
-----------------------------operator functions support-----------------------------
------------------------------------------------------------------------------------
-- +tinyint
CREATE INTERNAL FUNCTION sys_catalog.TINYINTPL(tinyint, tinyint)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintpl'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- -tinyint
CREATE INTERNAL FUNCTION sys_catalog.TINYINTMI(tinyint, tinyint)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintmi'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- *tinyint
CREATE INTERNAL FUNCTION sys_catalog.TINYINTMUL(tinyint, tinyint)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintmul'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- /tinyint
CREATE INTERNAL FUNCTION sys_catalog.TINYINTDIV(tinyint, tinyint)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintdiv'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- +int2
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT2PL(tinyint, int2)
RETURNS int2
AS 'MODULE_PATHNAME','tinyintint2pl'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- -int2
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT2MI(tinyint, int2)
RETURNS int2
AS 'MODULE_PATHNAME','tinyintint2mi'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- *int2
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT2MUL(tinyint, int2)
RETURNS int2
AS 'MODULE_PATHNAME','tinyintint2mul'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- /int2
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT2DIV(tinyint, int2)
RETURNS int2
AS 'MODULE_PATHNAME','tinyintint2div'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int2+
CREATE INTERNAL FUNCTION sys_catalog.INT2TINYINTPL(int2, tinyint)
RETURNS int2
AS 'MODULE_PATHNAME','int2tinyintpl'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int2-
CREATE INTERNAL FUNCTION sys_catalog.INT2TINYINTMI(int2, tinyint)
RETURNS int2
AS 'MODULE_PATHNAME','int2tinyintmi'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int2*
CREATE INTERNAL FUNCTION sys_catalog.INT2TINYINTMUL(INT2, TINYINT)
RETURNS int2
AS 'MODULE_PATHNAME','int2tinyintmul'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int2/
CREATE INTERNAL FUNCTION sys_catalog.INT2TINYINTDIV(INT2, TINYINT)
RETURNS int2
AS 'MODULE_PATHNAME','int2tinyintdiv'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- +int4
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT4PL(TINYINT, INT4)
RETURNS int4
AS 'MODULE_PATHNAME','tinyintint4pl'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- -int4
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT4MI(TINYINT, INT4)
RETURNS int4
AS 'MODULE_PATHNAME','tinyintint4mi'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- *int4
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT4MUL(TINYINT, INT4)
RETURNS int4
AS 'MODULE_PATHNAME','tinyintint4mul'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- /int4
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT4DIV(TINYINT, INT4)
RETURNS int4
AS 'MODULE_PATHNAME','tinyintint4div'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int4+
CREATE INTERNAL FUNCTION sys_catalog.INT4TINYINTPL(INT4, TINYINT)
RETURNS int4
AS 'MODULE_PATHNAME','int4tinyintpl'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int4-
CREATE INTERNAL FUNCTION sys_catalog.INT4TINYINTMI(INT4, TINYINT)
RETURNS int4
AS 'MODULE_PATHNAME','int4tinyintmi'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int4*
CREATE INTERNAL FUNCTION sys_catalog.INT4TINYINTMUL(INT4, TINYINT)
RETURNS int4
AS 'MODULE_PATHNAME','int4tinyintmul'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int4/
CREATE INTERNAL FUNCTION sys_catalog.INT4TINYINTDIV(INT4, TINYINT)
RETURNS int4
AS 'MODULE_PATHNAME','int4tinyintdiv'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- +int8
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT8PL(TINYINT, INT8)
RETURNS int8
AS 'MODULE_PATHNAME','tinyintint8pl'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- -int8
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT8MI(TINYINT, INT8)
RETURNS int8
AS 'MODULE_PATHNAME','tinyintint8mi'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- *int8
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT8MUL(TINYINT, INT8)
RETURNS int8
AS 'MODULE_PATHNAME','tinyintint8mul'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- /int8
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT8DIV(TINYINT, INT8)
RETURNS int8
AS 'MODULE_PATHNAME','tinyintint8div'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int8+
CREATE INTERNAL FUNCTION sys_catalog.INT8TINYINTPL(INT8, TINYINT)
RETURNS int8
AS 'MODULE_PATHNAME','int8tinyintpl'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int8-
CREATE INTERNAL FUNCTION sys_catalog.INT8TINYINTMI(INT8, TINYINT)
RETURNS int8
AS 'MODULE_PATHNAME','int8tinyintmi'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int8*
CREATE INTERNAL FUNCTION sys_catalog.INT8TINYINTMUL(INT8, TINYINT)
RETURNS int8
AS 'MODULE_PATHNAME','int8tinyintmul'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- int8/
CREATE INTERNAL FUNCTION sys_catalog.INT8TINYINTDIV(INT8, TINYINT)
RETURNS int8
AS 'MODULE_PATHNAME','int8tinyintdiv'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- *money
CREATE INTERNAL FUNCTION sys_catalog.TINYINT_MUL_CASH(TINYINT, MONEY)
RETURNS money
AS 'MODULE_PATHNAME','tinyint_mul_cash'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- money*
CREATE INTERNAL FUNCTION sys_catalog.CASH_MUL_TINYINT(MONEY, TINYINT)
RETURNS money
AS 'MODULE_PATHNAME','cash_mul_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- money/
CREATE INTERNAL FUNCTION sys_catalog.CASH_DIV_TINYINT(MONEY, TINYINT)
RETURNS money
AS 'MODULE_PATHNAME','cash_div_tinyint'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- compare tinyint with tinyint
-- ne
CREATE INTERNAL FUNCTION sys_catalog.TINYINTNE(TINYINT, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintne'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- lt
CREATE INTERNAL FUNCTION sys_catalog.TINYINTLT(TINYINT, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintlt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- le
CREATE INTERNAL FUNCTION sys_catalog.TINYINTLE(TINYINT, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintle'
LANGUAGE C
PARALLEL SAFE
STRICT
IMMUTABLE
LEAKPROOF;

-- gt
CREATE INTERNAL FUNCTION sys_catalog.TINYINTGT(TINYINT, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintgt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ge
CREATE INTERNAL FUNCTION sys_catalog.TINYINTGE(TINYINT, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintge'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- compare tinyint with int2
-- eq
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT2EQ(TINYINT, INT2)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint2eq'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ne
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT2NE(TINYINT, INT2)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint2ne'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- lt
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT2LT(TINYINT, INT2)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint2lt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- le
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT2LE(TINYINT, INT2)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint2le'
LANGUAGE C
PARALLEL SAFE
STRICT
IMMUTABLE
LEAKPROOF;

-- gt
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT2GT(TINYINT, INT2)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint2gt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ge
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT2GE(TINYINT, INT2)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint2ge'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- compare int2 with tinyint
-- eq
CREATE INTERNAL FUNCTION sys_catalog.INT2TINYINTEQ(INT2, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int2tinyinteq'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ne
CREATE INTERNAL FUNCTION sys_catalog.INT2TINYINTNE(INT2, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int2tinyintne'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- lt
CREATE INTERNAL FUNCTION sys_catalog.INT2TINYINTLT(INT2, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int2tinyintlt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- le
CREATE INTERNAL FUNCTION sys_catalog.INT2TINYINTLE(INT2, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int2tinyintle'
LANGUAGE C
PARALLEL SAFE
STRICT
IMMUTABLE
LEAKPROOF;

-- gt
CREATE INTERNAL FUNCTION sys_catalog.INT2TINYINTGT(INT2, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int2tinyintgt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ge
CREATE INTERNAL FUNCTION sys_catalog.INT2TINYINTGE(INT2, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int2tinyintge'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- compare tinyint with int4
-- eq
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT4EQ(TINYINT, INT4)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint4eq'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ne
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT4NE(TINYINT, INT4)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint4ne'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- lt
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT4LT(TINYINT, INT4)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint4lt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- le
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT4LE(TINYINT, INT4)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint4le'
LANGUAGE C
PARALLEL SAFE
STRICT
IMMUTABLE
LEAKPROOF;

-- gt
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT4GT(TINYINT, INT4)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint4gt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ge
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT4GE(TINYINT, INT4)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint4ge'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- compare int4 with tinyint
-- eq
CREATE INTERNAL FUNCTION sys_catalog.INT4TINYINTEQ(INT4, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int4tinyinteq'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ne
CREATE INTERNAL FUNCTION sys_catalog.INT4TINYINTNE(INT4, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int4tinyintne'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- lt
CREATE INTERNAL FUNCTION sys_catalog.INT4TINYINTLT(INT4, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int4tinyintlt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- le
CREATE INTERNAL FUNCTION sys_catalog.INT4TINYINTLE(INT4, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int4tinyintle'
LANGUAGE C
PARALLEL SAFE
STRICT
IMMUTABLE
LEAKPROOF;

-- gt
CREATE INTERNAL FUNCTION sys_catalog.INT4TINYINTGT(INT4, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int4tinyintgt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ge
CREATE INTERNAL FUNCTION sys_catalog.INT4TINYINTGE(INT4, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int4tinyintge'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- compare tinyint with int8
-- eq
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT8EQ(TINYINT, INT8)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint8eq'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ne
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT8NE(TINYINT, INT8)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint8ne'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- lt
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT8LT(TINYINT, INT8)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint8lt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- le
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT8LE(TINYINT, INT8)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint8le'
LANGUAGE C
PARALLEL SAFE
STRICT
IMMUTABLE
LEAKPROOF;

-- gt
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT8GT(TINYINT, INT8)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint8gt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ge
CREATE INTERNAL FUNCTION sys_catalog.TINYINTINT8GE(TINYINT, INT8)
RETURNS bool
AS 'MODULE_PATHNAME','tinyintint8ge'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- compare int8 with tinyint
-- eq
CREATE INTERNAL FUNCTION sys_catalog.INT8TINYINTEQ(INT8, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int8tinyinteq'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ne
CREATE INTERNAL FUNCTION sys_catalog.INT8TINYINTNE(INT8, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int8tinyintne'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- lt
CREATE INTERNAL FUNCTION sys_catalog.INT8TINYINTLT(INT8, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int8tinyintlt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- le
CREATE INTERNAL FUNCTION sys_catalog.INT8TINYINTLE(INT8, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int8tinyintle'
LANGUAGE C
PARALLEL SAFE
STRICT
IMMUTABLE
LEAKPROOF;

-- gt
CREATE INTERNAL FUNCTION sys_catalog.INT8TINYINTGT(INT8, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int8tinyintgt'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

-- ge
CREATE INTERNAL FUNCTION sys_catalog.INT8TINYINTGE(INT8, TINYINT)
RETURNS bool
AS 'MODULE_PATHNAME','int8tinyintge'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE
LEAKPROOF;

------------------------------------------------------------------------------------
----------------------------------operators support---------------------------------
------------------------------------------------------------------------------------
-- tinyint_(eq|ne|lt|le|gt|ge)

create operator sys_catalog.=(
	leftarg = TINYINT,
	rightarg  = TINYINT,
	procedure = TINYINTEQ,
	commutator = =,
	negator = <>,
	restrict = EQSEL,
	join = EQJOINSEL,
	hashes, merges
);

CREATE OPERATOR sys_catalog.<>(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintne,
	COMMUTATOR = <>,
	NEGATOR = =,
	RESTRICT = neqsel,
	JOIN = neqjoinsel
);

CREATE OPERATOR sys_catalog.<(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintlt,
	COMMUTATOR = >,
	NEGATOR = >=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.<=(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintle,
	COMMUTATOR = >=,
	NEGATOR = >,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintgt,
	COMMUTATOR = <,
	NEGATOR = <=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>=(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintge,
	COMMUTATOR = <=,
	NEGATOR = <,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

--tinyint_int2(eq|ne|lt|le|gt|ge)

CREATE OPERATOR sys_catalog.=(
	LEFTARG = tinyint,
	RIGHTARG  = int2,
	PROCEDURE = tinyintint2eq,
	COMMUTATOR = =,
	NEGATOR = <>,
	RESTRICT = eqsel,
	JOIN = eqjoinsel,
	HASHES, MERGES
);

CREATE OPERATOR sys_catalog.<>(
	LEFTARG = tinyint,
	RIGHTARG  = int2,
	PROCEDURE = tinyintint2ne,
	COMMUTATOR = <>,
	NEGATOR = =,
	RESTRICT = neqsel,
	JOIN = neqjoinsel
);

CREATE OPERATOR sys_catalog.<(
	LEFTARG = tinyint,
	RIGHTARG  = int2,
	PROCEDURE = tinyintint2lt,
	COMMUTATOR = >,
	NEGATOR = >=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.<=(
	LEFTARG = tinyint,
	RIGHTARG  = int2,
	PROCEDURE = tinyintint2le,
	COMMUTATOR = >=,
	NEGATOR = >,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>(
	LEFTARG = tinyint,
	RIGHTARG  = int2,
	PROCEDURE = tinyintint2gt,
	COMMUTATOR = <,
	NEGATOR = <=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>=(
	LEFTARG = tinyint,
	RIGHTARG  = int2,
	PROCEDURE = tinyintint2ge,
	COMMUTATOR = <=,
	NEGATOR = <,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

-- int2_tinyint(eq|ne|lt|le|gt|ge)

CREATE OPERATOR sys_catalog.=(
	LEFTARG = int2,
	RIGHTARG  = tinyint,
	PROCEDURE = int2tinyinteq,
	COMMUTATOR = =,
	NEGATOR = <>,
	RESTRICT = eqsel,
	JOIN = eqjoinsel,
	HASHES, MERGES
);

CREATE OPERATOR sys_catalog.<>(
	LEFTARG = int2,
	RIGHTARG  = tinyint,
	PROCEDURE = int2tinyintne,
	COMMUTATOR = <>,
	NEGATOR = =,
	RESTRICT = neqsel,
	JOIN = neqjoinsel
);

CREATE OPERATOR sys_catalog.<(
	LEFTARG = int2,
	RIGHTARG  = tinyint,
	PROCEDURE = int2tinyintlt,
	COMMUTATOR = >,
	NEGATOR = >=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.<=(
	LEFTARG = int2,
	RIGHTARG  = tinyint,
	PROCEDURE = int2tinyintle,
	COMMUTATOR = >=,
	NEGATOR = >,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>(
	LEFTARG = int2,
	RIGHTARG  = tinyint,
	PROCEDURE = int2tinyintgt,
	COMMUTATOR = <,
	NEGATOR = <=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>=(
	LEFTARG = int2,
	RIGHTARG  = tinyint,
	PROCEDURE = int2tinyintge,
	COMMUTATOR = <=,
	NEGATOR = <,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

-- tinyint_int4(eq|ne|lt|le|gt|ge)

CREATE OPERATOR sys_catalog.=(
	LEFTARG = tinyint,
	RIGHTARG  = int4,
	PROCEDURE = tinyintint4eq,
	COMMUTATOR = =,
	NEGATOR = <>,
	RESTRICT = eqsel,
	JOIN = eqjoinsel,
	HASHES, MERGES
);

CREATE OPERATOR sys_catalog.<>(
	LEFTARG = tinyint,
	RIGHTARG  = int4,
	PROCEDURE = tinyintint4ne,
	COMMUTATOR = <>,
	NEGATOR = =,
	RESTRICT = neqsel,
	JOIN = neqjoinsel
);

CREATE OPERATOR sys_catalog.<(
	LEFTARG = tinyint,
	RIGHTARG  = int4,
	PROCEDURE = tinyintint4lt,
	COMMUTATOR = >,
	NEGATOR = >=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.<=(
	LEFTARG = tinyint,
	RIGHTARG  = int4,
	PROCEDURE = tinyintint4le,
	COMMUTATOR = >=,
	NEGATOR = >,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>(
	LEFTARG = tinyint,
	RIGHTARG  = int4,
	PROCEDURE = tinyintint4gt,
	COMMUTATOR = <,
	NEGATOR = <=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>=(
	LEFTARG = tinyint,
	RIGHTARG  = int4,
	PROCEDURE = tinyintint4ge,
	COMMUTATOR = <=,
	NEGATOR = <,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

-- int4_tinyint(eq|ne|lt|le|gt|ge)

CREATE OPERATOR sys_catalog.=(
	LEFTARG = int4,
	RIGHTARG  = tinyint,
	PROCEDURE = int4tinyinteq,
	COMMUTATOR = =,
	NEGATOR = <>,
	RESTRICT = eqsel,
	JOIN = eqjoinsel,
	HASHES, MERGES
);

CREATE OPERATOR sys_catalog.<>(
	LEFTARG = int4,
	RIGHTARG  = tinyint,
	PROCEDURE = int4tinyintne,
	COMMUTATOR = <>,
	NEGATOR = =,
	RESTRICT = neqsel,
	JOIN = neqjoinsel
);

CREATE OPERATOR sys_catalog.<(
	LEFTARG = int4,
	RIGHTARG  = tinyint,
	PROCEDURE = int4tinyintlt,
	COMMUTATOR = >,
	NEGATOR = >=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.<=(
	LEFTARG = int4,
	RIGHTARG  = tinyint,
	PROCEDURE = int4tinyintle,
	COMMUTATOR = >=,
	NEGATOR = >,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>(
	LEFTARG = int4,
	RIGHTARG  = tinyint,
	PROCEDURE = int4tinyintgt,
	COMMUTATOR = <,
	NEGATOR = <=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>=(
	LEFTARG = int4,
	RIGHTARG  = tinyint,
	PROCEDURE = int4tinyintge,
	COMMUTATOR = <=,
	NEGATOR = <,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

-- tinyint_int8(eq|ne|lt|le|gt|ge)

CREATE OPERATOR sys_catalog.=(
	LEFTARG = tinyint,
	RIGHTARG  = int8,
	PROCEDURE = tinyintint8eq,
	COMMUTATOR = =,
	NEGATOR = <>,
	RESTRICT = eqsel,
	JOIN = eqjoinsel,
	HASHES, MERGES
);

CREATE OPERATOR sys_catalog.<>(
	LEFTARG = tinyint,
	RIGHTARG  = int8,
	PROCEDURE = tinyintint8ne,
	COMMUTATOR = <>,
	NEGATOR = =,
	RESTRICT = neqsel,
	JOIN = neqjoinsel
);

CREATE OPERATOR sys_catalog.<(
	LEFTARG = tinyint,
	RIGHTARG  = int8,
	PROCEDURE = tinyintint8lt,
	COMMUTATOR = >,
	NEGATOR = >=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.<=(
	LEFTARG = tinyint,
	RIGHTARG  = int8,
	PROCEDURE = tinyintint8le,
	COMMUTATOR = >=,
	NEGATOR = >,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>(
	LEFTARG = tinyint,
	RIGHTARG  = int8,
	PROCEDURE = tinyintint8gt,
	COMMUTATOR = <,
	NEGATOR = <=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>=(
	LEFTARG = tinyint,
	RIGHTARG  = int8,
	PROCEDURE = tinyintint8ge,
	COMMUTATOR = <=,
	NEGATOR = <,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

-- int8_tinyint(eq|ne|lt|le|gt|ge)

CREATE OPERATOR sys_catalog.=(
	LEFTARG = int8,
	RIGHTARG  = tinyint,
	PROCEDURE = int8tinyinteq,
	COMMUTATOR = =,
	NEGATOR = <>,
	RESTRICT = eqsel,
	JOIN = eqjoinsel,
	HASHES, MERGES
);

CREATE OPERATOR sys_catalog.<>(
	LEFTARG = int8,
	RIGHTARG  = tinyint,
	PROCEDURE = int8tinyintne,
	COMMUTATOR = <>,
	NEGATOR = =,
	RESTRICT = neqsel,
	JOIN = neqjoinsel
);

CREATE OPERATOR sys_catalog.<(
	LEFTARG = int8,
	RIGHTARG  = tinyint,
	PROCEDURE = int8tinyintlt,
	COMMUTATOR = >,
	NEGATOR = >=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.<=(
	LEFTARG = int8,
	RIGHTARG  = tinyint,
	PROCEDURE = int8tinyintle,
	COMMUTATOR = >=,
	NEGATOR = >,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>(
	LEFTARG = int8,
	RIGHTARG  = tinyint,
	PROCEDURE = int8tinyintgt,
	COMMUTATOR = <,
	NEGATOR = <=,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

CREATE OPERATOR sys_catalog.>=(
	LEFTARG = int8,
	RIGHTARG  = tinyint,
	PROCEDURE = int8tinyintge,
	COMMUTATOR = <=,
	NEGATOR = <,
	RESTRICT = scalarltsel,
	JOIN = scalarltjoinsel
);

-- tinyint <-> tinyint

CREATE OPERATOR sys_catalog.+(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintpl,
	COMMUTATOR = +
);

CREATE OPERATOR sys_catalog.-(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintmi
);

CREATE OPERATOR sys_catalog.*(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintmul,
	COMMUTATOR = *
);

CREATE OPERATOR sys_catalog./(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintdiv,
	COMMUTATOR = /
);

-- tinyint <-> int2

CREATE OPERATOR sys_catalog.+(
	LEFTARG = tinyint,
	RIGHTARG  = int2,
	PROCEDURE = tinyintint2pl,
	COMMUTATOR = +
);

CREATE OPERATOR sys_catalog.-(
	LEFTARG = tinyint,
	RIGHTARG  = int2,
	PROCEDURE = tinyintint2mi
);

CREATE OPERATOR sys_catalog.*(
	LEFTARG = tinyint,
	RIGHTARG  = int2,
	PROCEDURE = tinyintint2mul,
	COMMUTATOR = *
);

CREATE OPERATOR sys_catalog./(
	LEFTARG = tinyint,
	RIGHTARG  = int2,
	PROCEDURE = tinyintint2div,
	COMMUTATOR = /
);

-- int2 <-> tinyint

CREATE OPERATOR sys_catalog.+(
	LEFTARG = int2,
	RIGHTARG  = tinyint,
	PROCEDURE = int2tinyintpl,
	COMMUTATOR = +
);

CREATE OPERATOR sys_catalog.-(
	LEFTARG = int2,
	RIGHTARG  = tinyint,
	PROCEDURE = int2tinyintmi
);

CREATE OPERATOR sys_catalog.*(
	LEFTARG = int2,
	RIGHTARG  = tinyint,
	PROCEDURE = int2tinyintmul,
	COMMUTATOR = *
);

CREATE OPERATOR sys_catalog./(
	LEFTARG = int2,
	RIGHTARG  = tinyint,
	PROCEDURE = int2tinyintdiv,
	COMMUTATOR = /
);

-- tinyint <-> int4

CREATE OPERATOR sys_catalog.+(
	LEFTARG = tinyint,
	RIGHTARG  = int4,
	PROCEDURE = tinyintint4pl,
	COMMUTATOR = +
);

CREATE OPERATOR sys_catalog.-(
	LEFTARG = tinyint,
	RIGHTARG  = int4,
	PROCEDURE = tinyintint4mi
);

CREATE OPERATOR sys_catalog.*(
	LEFTARG = tinyint,
	RIGHTARG  = int4,
	PROCEDURE = tinyintint4mul,
	COMMUTATOR = *
);

CREATE OPERATOR sys_catalog./(
	LEFTARG = tinyint,
	RIGHTARG  = int4,
	PROCEDURE = tinyintint4div,
	COMMUTATOR = /
);

-- int4 <-> tinyint

CREATE OPERATOR sys_catalog.+(
	LEFTARG = int4,
	RIGHTARG  = tinyint,
	PROCEDURE = int4tinyintpl,
	COMMUTATOR = +
);

CREATE OPERATOR sys_catalog.-(
	LEFTARG = int4,
	RIGHTARG  = tinyint,
	PROCEDURE = int4tinyintmi
);

CREATE OPERATOR sys_catalog.*(
	LEFTARG = int4,
	RIGHTARG  = tinyint,
	PROCEDURE = int4tinyintmul,
	COMMUTATOR = *
);

CREATE OPERATOR sys_catalog./(
	LEFTARG = int4,
	RIGHTARG  = tinyint,
	PROCEDURE = int4tinyintdiv,
	COMMUTATOR = /
);

-- tinyint <-> int8

CREATE OPERATOR sys_catalog.+(
	LEFTARG = tinyint,
	RIGHTARG  = int8,
	PROCEDURE = tinyintint8pl,
	COMMUTATOR = +
);

CREATE OPERATOR sys_catalog.-(
	LEFTARG = tinyint,
	RIGHTARG  = int8,
	PROCEDURE = tinyintint8mi
);

CREATE OPERATOR sys_catalog.*(
	LEFTARG = tinyint,
	RIGHTARG  = int8,
	PROCEDURE = tinyintint8mul,
	COMMUTATOR = *
);

CREATE OPERATOR sys_catalog./(
	LEFTARG = tinyint,
	RIGHTARG  = int8,
	PROCEDURE = tinyintint8div,
	COMMUTATOR = /
);

-- int8 <-> tinyint

CREATE OPERATOR sys_catalog.+(
	LEFTARG = int8,
	RIGHTARG  = tinyint,
	PROCEDURE = int8tinyintpl,
	COMMUTATOR = +
);

CREATE OPERATOR sys_catalog.-(
	LEFTARG = int8,
	RIGHTARG  = tinyint,
	PROCEDURE = int8tinyintmi
);

CREATE OPERATOR sys_catalog.*(
	LEFTARG = int8,
	RIGHTARG  = tinyint,
	PROCEDURE = int8tinyintmul,
	COMMUTATOR = *
);

CREATE OPERATOR sys_catalog./(
	LEFTARG = int8,
	RIGHTARG  = tinyint,
	PROCEDURE = int8tinyintdiv,
	COMMUTATOR = /
);

-- tinyint <-> money

CREATE OPERATOR sys_catalog.*(
	LEFTARG = tinyint,
	RIGHTARG  = money,
	PROCEDURE = tinyint_mul_cash,
	COMMUTATOR = *
);

CREATE OPERATOR sys_catalog.*(
	LEFTARG = money,
	RIGHTARG  = tinyint,
	PROCEDURE = cash_mul_tinyint,
	COMMUTATOR = *
);

CREATE OPERATOR sys_catalog./(
	LEFTARG = money,
	RIGHTARG  = tinyint,
	PROCEDURE = cash_div_tinyint
);

--------------------------------------------------------------------------
------------------------------index support-------------------------------
--------------------------------------------------------------------------

CREATE INTERNAL FUNCTION sys_catalog.BTTINYINTCMP(tinyint, tinyint)
RETURNS int4
AS 'MODULE_PATHNAME','bttinyintcmp'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.BTTINYINTINT2CMP(TINYINT, INT2)
RETURNS int4
AS 'MODULE_PATHNAME','bttinyintint2cmp'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.BTTINYINTINT4CMP(TINYINT, INT4)
RETURNS int4
AS 'MODULE_PATHNAME','bttinyintint4cmp'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.BTTINYINTINT8CMP(TINYINT, INT8)
RETURNS int4
AS 'MODULE_PATHNAME','bttinyintint8cmp'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.BTINT2TINYINTCMP(INT2, TINYINT)
RETURNS int4
AS 'MODULE_PATHNAME','btint2tinyintcmp'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.BTINT4TINYINTCMP(INT4, TINYINT)
RETURNS int4
AS 'MODULE_PATHNAME','btint4tinyintcmp'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.BTINT8TINYINTCMP(INT8, TINYINT)
RETURNS int4
AS 'MODULE_PATHNAME','btint8tinyintcmp'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- sort support
CREATE INTERNAL FUNCTION sys_catalog.BTTINYINTSORTSUPPORT(INTERNAL)
RETURNS void
AS 'MODULE_PATHNAME','bttinyintsortsupport'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

------------------------------------------------------------------------------------
---------------------------mathematics functions support----------------------------
------------------------------------------------------------------------------------
-- mod
CREATE INTERNAL FUNCTION sys_catalog.MOD(TINYINT, TINYINT)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintmod'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.TINYINTMOD(TINYINT, TINYINT)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintmod'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- abs
CREATE INTERNAL FUNCTION sys_catalog.ABS(TINYINT)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintabs'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.TINYINTABS(TINYINT)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintabs'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- and
CREATE INTERNAL FUNCTION sys_catalog.TINYINTAND(TINYINT, TINYINT)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintand'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- or
CREATE INTERNAL FUNCTION sys_catalog.TINYINTOR(TINYINT, TINYINT)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintor'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- xor
CREATE INTERNAL FUNCTION sys_catalog.TINYINTXOR(TINYINT, TINYINT)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintxor'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- shl
CREATE INTERNAL FUNCTION sys_catalog.TINYINTSHL(TINYINT, INT4)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintshl'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- shr
CREATE INTERNAL FUNCTION sys_catalog.TINYINTSHR(TINYINT, INT4)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintshr'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- not
CREATE INTERNAL FUNCTION sys_catalog.TINYINTNOT(TINYINT)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintnot'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- um
CREATE INTERNAL FUNCTION sys_catalog.TINYINTUM(TINYINT)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintum'
LANGUAGE C
PARALLEL SAFE
STRICT
IMMUTABLE;

-- up
CREATE INTERNAL FUNCTION sys_catalog.TINYINTUP(TINYINT)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintup'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

------------------------------------------------------------------------------------
---------------------------mathematics operators support----------------------------
------------------------------------------------------------------------------------

CREATE OPERATOR sys_catalog.@(
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintabs
);

CREATE OPERATOR sys_catalog.+(
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintup
);

CREATE OPERATOR sys_catalog.-(
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintum
);

CREATE OPERATOR sys_catalog.&(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintand,
	COMMUTATOR = &
);

CREATE OPERATOR sys_catalog.|(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintor,
	COMMUTATOR = |
);

CREATE OPERATOR sys_catalog.#(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintxor,
	COMMUTATOR = #
);

CREATE OPERATOR sys_catalog.~(
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintnot
);

CREATE OPERATOR sys_catalog.<<(
	LEFTARG = tinyint,
	RIGHTARG  = int,
	PROCEDURE = tinyintshl
);

CREATE OPERATOR sys_catalog.>>(
	LEFTARG = tinyint,
	RIGHTARG  = int,
	PROCEDURE = tinyintshr
);

CREATE OPERATOR sys_catalog.%(
	LEFTARG = tinyint,
	RIGHTARG  = tinyint,
	PROCEDURE = tinyintmod
);

------------------------------------------------------------------------------------
---------------------------aggregation functions support----------------------------
------------------------------------------------------------------------------------
-- larger
CREATE INTERNAL FUNCTION sys_catalog.TINYINTLARGER(TINYINT, TINYINT)
returns TINYINT
AS 'MODULE_PATHNAME','tinyintlarger'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- smaller
CREATE INTERNAL FUNCTION sys_catalog.TINYINTSMALLER(TINYINT, TINYINT)
RETURNS tinyint
AS 'MODULE_PATHNAME','tinyintsmaller'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- accum avg
CREATE INTERNAL FUNCTION sys_catalog.TINYINT_AVG_ACCUM(_INT8, TINYINT)
RETURNS _int8
AS 'MODULE_PATHNAME','tinyint_avg_accum'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.TINYINT_ACCUM_INV(INTERNAL, TINYINT)
RETURNS internal
AS 'MODULE_PATHNAME','tinyint_accum_inv'
LANGUAGE C
PARALLEL SAFE
IMMUTABLE;

CREATE INTERNAL FUNCTION sys_catalog.TINYINT_AVG_ACCUM_INV(_INT8, TINYINT)
RETURNS _int8
AS 'MODULE_PATHNAME','tinyint_avg_accum_inv'
LANGUAGE C
STRICT
PARALLEL SAFE
IMMUTABLE;

-- sum
CREATE INTERNAL FUNCTION sys_catalog.TINYINT_SUM(INT8, TINYINT)
RETURNS int8
AS 'MODULE_PATHNAME','tinyint_sum'
LANGUAGE C
PARALLEL SAFE
IMMUTABLE;

CREATE AGGREGATE sys_catalog.AVG(TINYINT)(
	SFUNC = tinyint_avg_accum,
	STYPE = _int8,
	FINALFUNC = int8_avg,
	COMBINEFUNC = int4_avg_combine,
	initcond = '{0,0}',
	MSFUNC = tinyint_avg_accum,
	MSTYPE = _int8,
	MINVFUNC = tinyint_avg_accum_inv,
	MFINALFUNC = int8_avg,
	MINITCOND = '{0,0}',
	PARALLEL = SAFE
);

CREATE AGGREGATE sys_catalog.SUM(TINYINT)(
	SFUNC = tinyint_sum,
	STYPE = int8,
	COMBINEFUNC = int8pl,
	MSFUNC = tinyint_avg_accum,
	MSTYPE = _int8,
	MINVFUNC = tinyint_avg_accum_inv,
	MFINALFUNC = int2int4_sum,
	MINITCOND = '{0,0}',
	PARALLEL = SAFE
);

CREATE AGGREGATE sys_catalog.MAX(TINYINT)(
	SFUNC = tinyintlarger,
	FINALFUNC_EXTRA,
	STYPE = tinyint,
	COMBINEFUNC = tinyintlarger,
	SORTOP = >,
	PARALLEL = SAFE
);

CREATE AGGREGATE sys_catalog.MIN(TINYINT)(
	SFUNC = tinyintsmaller,
	STYPE = tinyint,
	FINALFUNC_EXTRA,
	COMBINEFUNC = tinyintsmaller,
	SORTOP = <,
	PARALLEL = SAFE
);

CREATE AGGREGATE sys_catalog.VAR_POP(TINYINT)(
	SFUNC = tinyint_accum,
	STYPE = internal,
	FINALFUNC = numeric_poly_var_pop,
	SSPACE = 48,
	COMBINEFUNC = numeric_poly_combine,
	SERIALFUNC = numeric_poly_serialize,
	DESERIALFUNC = numeric_poly_deserialize,
	MSFUNC = tinyint_accum,
	MSTYPE = internal,
	MINVFUNC = tinyint_accum_inv,
	MFINALFUNC = numeric_poly_var_pop,
	MSSPACE = 48,
	PARALLEL = SAFE
);

CREATE AGGREGATE sys_catalog.VAR_SAMP(TINYINT)(
	SFUNC = tinyint_accum,
	STYPE = internal,
	FINALFUNC = numeric_poly_var_samp,
	SSPACE = 48,
	COMBINEFUNC = numeric_poly_combine,
	SERIALFUNC = numeric_poly_serialize,
	DESERIALFUNC = numeric_poly_deserialize,
	MSFUNC = tinyint_accum,
	MSTYPE = internal,
	MINVFUNC = tinyint_accum_inv,
	MFINALFUNC = numeric_poly_var_samp,
	MSSPACE = 48,
	PARALLEL = SAFE
);

-- variance: historical Kingbase syntax for var_samp

CREATE AGGREGATE sys_catalog.VARIANCE(TINYINT)(
	SFUNC = tinyint_accum,
	STYPE = internal,
	FINALFUNC = numeric_poly_var_samp,
	SSPACE = 48,
	COMBINEFUNC = numeric_poly_combine,
	SERIALFUNC = numeric_poly_serialize,
	DESERIALFUNC = numeric_poly_deserialize,
	MSFUNC = tinyint_accum,
	MSTYPE = internal,
	MINVFUNC = tinyint_accum_inv,
	MFINALFUNC = numeric_poly_var_samp,
	MSSPACE = 48,
	PARALLEL = SAFE
);

CREATE AGGREGATE sys_catalog.STDDEV_POP(TINYINT)(
	SFUNC = tinyint_accum,
	STYPE = internal,
	SSPACE = 48,
	FINALFUNC = numeric_poly_stddev_pop,
	COMBINEFUNC = numeric_poly_combine,
	SERIALFUNC = numeric_poly_serialize,
	DESERIALFUNC = numeric_poly_deserialize,
	MSFUNC = tinyint_accum,
	MSTYPE = internal,
	MSSPACE = 48,
	MINVFUNC = tinyint_accum_inv,
	MFINALFUNC = numeric_poly_stddev_pop,
	PARALLEL = SAFE
);

CREATE AGGREGATE sys_catalog.STDDEV_SAMP(TINYINT)(
	SFUNC = tinyint_accum,
	STYPE = internal,
	SSPACE = 48,
	FINALFUNC = numeric_poly_stddev_samp,
	COMBINEFUNC = numeric_poly_combine,
	SERIALFUNC = numeric_poly_serialize,
	DESERIALFUNC = numeric_poly_deserialize,
	MSFUNC = tinyint_accum,
	MSTYPE = internal,
	MSSPACE = 48,
	MINVFUNC = tinyint_accum_inv,
	MFINALFUNC = numeric_poly_stddev_samp,
	PARALLEL = SAFE
);

CREATE AGGREGATE sys_catalog.STDDEV(TINYINT)(
	SFUNC = tinyint_accum,
	STYPE = internal,
	SSPACE = 48,
	FINALFUNC = numeric_poly_stddev_samp,
	COMBINEFUNC = numeric_poly_combine,
	SERIALFUNC = numeric_poly_serialize,
	DESERIALFUNC = numeric_poly_deserialize,
	MSFUNC = tinyint_accum,
	MSTYPE = internal,
	MSSPACE = 48,
	MINVFUNC = tinyint_accum_inv,
	MFINALFUNC = numeric_poly_stddev_samp,
	PARALLEL = SAFE
);

CREATE AGGREGATE sys_catalog.BIT_AND(TINYINT)(
	SFUNC = tinyintand,
	STYPE = tinyint,
	COMBINEFUNC = tinyintand,
	PARALLEL = SAFE
);

CREATE AGGREGATE sys_catalog.BIT_OR(TINYINT)(
	SFUNC = tinyintor,
	STYPE = tinyint,
	COMBINEFUNC = tinyintor,
	PARALLEL = SAFE
);

------------------------------------------------------------------------------------
---------------------------------btree support--------------------------------------
------------------------------------------------------------------------------------

CREATE OPERATOR CLASS sys_catalog.TINYINT_OPS
DEFAULT FOR TYPE tinyint USING btree FAMILY integer_ops AS
-- standard tinyint compare
	OPERATOR 1 < ,
	OPERATOR 2 <= ,
	OPERATOR 3 = ,
	OPERATOR 4 >= ,
	OPERATOR 5 > ,
	FUNCTION 1 bttinyintcmp(tinyint, tinyint) ,
	FUNCTION 2 bttinyintsortsupport(internal) ,

-- trans-type int8 compare int8 vs tinyint
	OPERATOR 1 < (int8, tinyint) ,
	OPERATOR 2 <= (int8, tinyint) ,
	OPERATOR 3 = (int8, tinyint) ,
	OPERATOR 4 >= (int8, tinyint) ,
	OPERATOR 5 > (int8, tinyint) ,
	FUNCTION 1 btint8tinyintcmp(int8, tinyint) ,

-- trans-type int4 compare int4 vs tinyint
	OPERATOR 1 < (int4, tinyint) ,
	OPERATOR 2 <= (int4, tinyint) ,
	OPERATOR 3 = (int4, tinyint) ,
	OPERATOR 4 >= (int4, tinyint) ,
	OPERATOR 5 > (int4, tinyint) ,
	FUNCTION 1 btint4tinyintcmp(int4, tinyint) ,

-- trans-type int2 compare int2 vs tinyint
	OPERATOR 1 < (int2, tinyint) ,
	OPERATOR 2 <= (int2, tinyint) ,
	OPERATOR 3 = (int2, tinyint) ,
	OPERATOR 4 >= (int2, tinyint) ,
	OPERATOR 5 > (int2, tinyint) ,
	FUNCTION 1 btint2tinyintcmp(int2, tinyint) ,

-- trans-type int8 compare tinyint vs int8
	OPERATOR 1 < (tinyint, int8) ,
	OPERATOR 2 <= (tinyint, int8) ,
	OPERATOR 3 = (tinyint, int8) ,
	OPERATOR 4 >= (tinyint, int8) ,
	OPERATOR 5 > (tinyint, int8) ,
	FUNCTION 1 bttinyintint8cmp(tinyint, int8) ,

-- trans-type int4 compare tinyint vs int4
	OPERATOR 1 < (tinyint, int4) ,
	OPERATOR 2 <= (tinyint, int4) ,
	OPERATOR 3 = (tinyint, int4) ,
	OPERATOR 4 >= (tinyint, int4) ,
	OPERATOR 5 > (tinyint, int4) ,
	FUNCTION 1 bttinyintint4cmp(tinyint, int4) ,

-- trans-type int2 compare tinyint vs int2
	OPERATOR 1 < (tinyint, int2) ,
	OPERATOR 2 <= (tinyint, int2) ,
	OPERATOR 3 = (tinyint, int2) ,
	OPERATOR 4 >= (tinyint, int2) ,
	OPERATOR 5 > (tinyint, int2) ,
	FUNCTION 1 bttinyintint2cmp(tinyint, int2) ;

------------------------------------------------------------------------------------
--------------------------------hash support----------------------------------------
------------------------------------------------------------------------------------

CREATE OPERATOR CLASS sys_catalog.TINYINT_OPS
DEFAULT FOR TYPE tinyint USING hash FAMILY integer_ops AS
-- standard tinyint compare
	OPERATOR 1 = ,
	OPERATOR 1 = (int8, tinyint) ,
	OPERATOR 1 = (int4, tinyint) ,
	OPERATOR 1 = (int2, tinyint) ,
	OPERATOR 1 = (tinyint, int8) ,
	OPERATOR 1 = (tinyint, int4) ,
	OPERATOR 1 = (tinyint, int2) ,
	FUNCTION 1 hashtinyint(tinyint) ;

------------------------------------------------------------------------------------
--------------------------------gin support-----------------------------------------
------------------------------------------------------------------------------------

CREATE OPERATOR CLASS sys_catalog._TINYINT_OPS
DEFAULT FOR TYPE _tinyint USING gin FAMILY array_ops AS
-- standard _tinyint compare
	FUNCTION 1 (_tinyint, _tinyint) bttinyintcmp (tinyint, tinyint) ,
	FUNCTION 2 (_tinyint, _tinyint) sys_catalog.ginarrayextract(anyarray, internal, internal) ,
	FUNCTION 3 (_tinyint, _tinyint) ginqueryarrayextract(anyarray, internal, int2, internal, internal, internal, internal) ,
	FUNCTION 4 (_tinyint, _tinyint) ginarrayconsistent(internal, int2, anyarray, int4, internal, internal, internal, internal) ,
	FUNCTION 6 (_tinyint, _tinyint) ginarraytriconsistent(internal, int2, anyarray, int4, internal, internal, internal) ,
	STORAGE tinyint ;

------------------------------------------------------------------------------------
--------------------------------brin support-----------------------------------------
------------------------------------------------------------------------------------

CREATE OPERATOR CLASS sys_catalog.TINYINT_MINMAX_OPS
DEFAULT FOR TYPE tinyint USING brin FAMILY integer_minmax_ops AS
-- standard tinyint compare
	OPERATOR 1 < ,
	OPERATOR 2 <= ,
	OPERATOR 3 = ,
	OPERATOR 4 >= ,
	OPERATOR 5 > ,
	FUNCTION 1 brin_minmax_opcinfo(internal) ,
	FUNCTION 2 brin_minmax_add_value(internal, internal, internal, internal) ,
	FUNCTION 3 brin_minmax_consistent(internal, internal, internal) ,
	FUNCTION 4 brin_minmax_union(internal, internal, internal) ,

-- trans-type int8 compare int8 vs tinyint
	OPERATOR 1 < (int8, tinyint) ,
	OPERATOR 2 <= (int8, tinyint) ,
	OPERATOR 3 = (int8, tinyint) ,
	OPERATOR 4 >= (int8, tinyint) ,
	OPERATOR 5 > (int8, tinyint) ,
	FUNCTION 1 (int8, tinyint) brin_minmax_opcinfo(internal) ,
	FUNCTION 2 (int8, tinyint) brin_minmax_add_value(internal, internal, internal, internal) ,
	FUNCTION 3 (int8, tinyint) brin_minmax_consistent(internal, internal, internal) ,
	FUNCTION 4 (int8, tinyint) brin_minmax_union(internal, internal, internal) ,

-- trans-type int4 compare int4 vs tinyint
	OPERATOR 1 < (int4, tinyint) ,
	OPERATOR 2 <= (int4, tinyint) ,
	OPERATOR 3 = (int4, tinyint) ,
	OPERATOR 4 >= (int4, tinyint) ,
	OPERATOR 5 > (int4, tinyint) ,
	FUNCTION 1 (int4, tinyint) brin_minmax_opcinfo(internal) ,
	FUNCTION 2 (int4, tinyint) brin_minmax_add_value(internal, internal, internal, internal) ,
	FUNCTION 3 (int4, tinyint) brin_minmax_consistent(internal, internal, internal) ,
	FUNCTION 4 (int4, tinyint) brin_minmax_union(internal, internal, internal) ,

-- trans-type int2 compare int2 vs tinyint
	OPERATOR 1 < (int2, tinyint) ,
	OPERATOR 2 <= (int2, tinyint) ,
	OPERATOR 3 = (int2, tinyint) ,
	OPERATOR 4 >= (int2, tinyint) ,
	OPERATOR 5 > (int2, tinyint) ,
	FUNCTION 1 (int2, tinyint) brin_minmax_opcinfo(internal) ,
	FUNCTION 2 (int2, tinyint) brin_minmax_add_value(internal, internal, internal, internal) ,
	FUNCTION 3 (int2, tinyint) brin_minmax_consistent(internal, internal, internal) ,
	FUNCTION 4 (int2, tinyint) brin_minmax_union(internal, internal, internal) ,

-- trans-type int8 compare tinyint vs int8
	OPERATOR 1 < (tinyint, int8) ,
	OPERATOR 2 <= (tinyint, int8) ,
	OPERATOR 3 = (tinyint, int8) ,
	OPERATOR 4 >= (tinyint, int8) ,
	OPERATOR 5 > (tinyint, int8) ,
	FUNCTION 1 (tinyint, int8) brin_minmax_opcinfo(internal) ,
	FUNCTION 2 (tinyint, int8) brin_minmax_add_value(internal, internal, internal, internal) ,
	FUNCTION 3 (tinyint, int8) brin_minmax_consistent(internal, internal, internal) ,
	FUNCTION 4 (tinyint, int8) brin_minmax_union(internal, internal, internal) ,

-- trans-type int4 compare tinyint vs int4
	OPERATOR 1 < (tinyint, int4) ,
	OPERATOR 2 <= (tinyint, int4) ,
	OPERATOR 3 = (tinyint, int4) ,
	OPERATOR 4 >= (tinyint, int4) ,
	OPERATOR 5 > (tinyint, int4) ,
	FUNCTION 1 (tinyint, int4) brin_minmax_opcinfo(internal) ,
	FUNCTION 2 (tinyint, int4) brin_minmax_add_value(internal, internal, internal, internal) ,
	FUNCTION 3 (tinyint, int4) brin_minmax_consistent(internal, internal, internal) ,
	FUNCTION 4 (tinyint, int4) brin_minmax_union(internal, internal, internal) ,

-- trans-type int2 compare tinyint vs int2
	OPERATOR 1 < (tinyint, int2) ,
	OPERATOR 2 <= (tinyint, int2) ,
	OPERATOR 3 = (tinyint, int2) ,
	OPERATOR 4 >= (tinyint, int2) ,
	OPERATOR 5 > (tinyint, int2) ,
	FUNCTION 1 (tinyint, int2) brin_minmax_opcinfo(internal) ,
	FUNCTION 2 (tinyint, int2) brin_minmax_add_value(internal, internal, internal, internal) ,
	FUNCTION 3 (tinyint, int2) brin_minmax_consistent(internal, internal, internal) ,
	FUNCTION 4 (tinyint, int2) brin_minmax_union(internal, internal, internal) ;

reset search_path;
