/* sysaudit/sysaudit--1.0--1.1.1.sql */

-- complain if script is sourced in ksql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION sysaudit" to load this file.\quit

-- nothing to do, this corrects the initially incorrect version for 9.6
