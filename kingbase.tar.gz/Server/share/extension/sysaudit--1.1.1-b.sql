/* sysaudit/sysaudit--1.1.1.sql */

-- complain if script is sourced in ksql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION sysaudit" to load this file.\quit

CREATE FUNCTION sysaudit_ddl_command_end()
    RETURNS event_trigger
    LANGUAGE C
    AS 'MODULE_PATHNAME', 'sysaudit_ddl_command_end';

CREATE EVENT TRIGGER sysaudit_ddl_command_end
    ON ddl_command_end
    EXECUTE PROCEDURE sysaudit_ddl_command_end();

CREATE FUNCTION sysaudit_sql_drop()
    RETURNS event_trigger
    LANGUAGE C
    AS 'MODULE_PATHNAME', 'sysaudit_sql_drop';

CREATE EVENT TRIGGER sysaudit_sql_drop
    ON sql_drop
    EXECUTE PROCEDURE sysaudit_sql_drop();

/* KingbaseES_BEGIN */
CREATE TABLE sysaudit.sysaudit_rule(
    user_name   VARCHAR(128),
    audit_rule  TEXT,
    set_user   VARCHAR(128)
);

CREATE TABLE sysaudit.sysaudit_setting(
    auditor      VARCHAR(128),
    audit_set    TEXT,
    setting_time TIMESTAMP
);

CREATE VIEW sysaudit.sysaudit_settings AS
    SELECT
        auditor,
        audit_set,
        setting_time
     FROM sysaudit.sysaudit_setting;

CREATE FUNCTION sysaudit.check_audit_rule(
    audit_type    VARCHAR(30),
    user_name     VARCHAR(128),
    audit_kind    VARCHAR(10),
    object_kind   VARCHAR(10),
    schema_name   VARCHAR(128),
    object_name   VARCHAR(128),
    audit_event   VARCHAR(10)
    )RETURNS BOOLEAN AS $$
DECLARE
    object_type TEXT DEFAULT NULL;
    count      INT DEFAULT 0;
    namespace  OID DEFAULT 0;
    enable_audit INT DEFAULT 0;
BEGIN
    EXECUTE 'show enable_audit;' INTO enable_audit;
    IF enable_audit = 0 THEN
        RAISE WARNING 'The ENABLE_AUDIT is ''%'', please set it to 1 or 2 at first!', enable_audit;
        RETURN FALSE;
    ELSIF enable_audit <> 0 AND enable_audit <> 1 AND enable_audit <> 2 THEN
        RAISE WARNING 'The ENABLE_AUDIT = ''%'' is not a vaild value.', enable_audit;
        RETURN FALSE;
    END IF;

    IF audit_type IS NULL THEN
        RAISE WARNING 'AUDIT_TYPE values are not allowed to be NULL, set failed.';
        RETURN FALSE;
    END IF;

    IF audit_kind  IS NULL THEN
        RAISE WARNING 'AUDIT_KIND values are not allowed to be NULL, set failed.';
        RETURN FALSE;
    END IF;

    IF audit_event IS NULL THEN
        RAISE WARNING 'AUDIT_EVENT values are not allowed to be NULL, set failed.';
        RETURN FALSE;
    END IF;

    IF user_name IS NOT NULL THEN
        SELECT count(*) INTO count FROM sys_user WHERE usename = user_name;
        IF count = 0 THEN
            RAISE WARNING 'user ''%'' does not exist, set failed.', user_name;
            RETURN FALSE;
        END IF;
    END IF;

    CASE UPPER(audit_kind)
    WHEN 'ACCESS'  THEN NULL;
    WHEN 'SESSION' THEN NULL;
    ELSE
        RAISE WARNING 'invalid AUDIT_KIND value: ''%'', set failed;', audit_kind;
        RETURN FALSE;
    END CASE;

    IF object_kind IS NOT NULL AND schema_name IS NOT NULL AND object_name IS NOT NULL THEN

        SELECT count(*) INTO count FROM sys_namespace WHERE nspname = schema_name AND nspparent = 0;
        IF count = 1 THEN
            SELECT oid INTO namespace FROM sys_namespace WHERE nspname = schema_name AND nspparent = 0;
        ELSE
            RAISE WARNING 'schema ''%'' does not exist, set failed.', schema_name;
            RETURN FALSE;
        END IF;

        CASE object_kind
        WHEN 'TABLE' THEN
            SELECT count(*) INTO count FROM sys_class WHERE relname = object_name AND relnamespace = namespace AND relkind = 'r';
            IF count = 0 THEN
                object_type = 'table';
            END IF;
        WHEN 'VIEW' THEN
            SELECT count(*)INTO count FROM sys_class WHERE relname = object_name AND relnamespace = namespace AND (relkind = 'v' OR relkind = 'm');
            IF count = 0 THEN
                object_type = 'view';
            END IF;
        WHEN 'SEQUENCE' THEN
            SELECT count(*) INTO count FROM sys_class WHERE relname = object_name AND relnamespace = namespace AND relkind = 'S';
            IF count = 0 THEN
                object_type = 'sequence';
            END IF;
        WHEN 'FUNCTION' THEN
            SELECT count(*) INTO count FROM sys_proc WHERE proname = object_name AND pronamespace = namespace AND protype = 'f';
            IF count = 0 THEN
                object_type = 'function';
            END IF;
        WHEN 'PROCEDURE' THEN
            SELECT count(*) INTO count FROM sys_proc WHERE proname = object_name AND pronamespace = namespace AND protype = 'p';
            IF count = 0 THEN
                object_type = 'procedure';
            END IF;
        WHEN 'PACKAGE' THEN
            SELECT count(*) INTO count FROM sys_package WHERE pkgname = object_name AND pkgnamespace = namespace;
            IF count = 0 THEN
                object_type = 'package';
            END IF;
        ELSE
            RAISE WARNING 'invalid OBJECT_KIND value: ''%'', set failed;', object_kind;
            RETURN FALSE;
        END CASE;

        IF object_type IS NOT NULL THEN
            RAISE WARNING '% ''%'' does not exist, set failed.', object_type, object_name;
            RETURN FALSE;
        END IF;
    END IF;

    CASE audit_event
    WHEN 'ALL'        THEN NULL;
    WHEN 'NONE'       THEN NULL;
    WHEN 'SUCCESSFUL' THEN NULL;
    WHEN 'FAILED'     THEN NULL;
    ELSE
        RAISE WARNING 'invalid AUDIT_EVENT value: ''%'', set failed;', audit_event;
        RETURN FALSE;
    END CASE;

    RETURN TRUE;
END;
$$ LANGUAGE plsql;

CREATE FUNCTION sysaudit.set_audit_rule(
    audit_type    VARCHAR(30),
    user_name     VARCHAR(128),
    audit_kind    VARCHAR(10),
    object_kind   VARCHAR(10),
    schema_name   VARCHAR(128),
    object_name   VARCHAR(128),
    audit_event   VARCHAR(10),
    is_set        BOOLEAN
    )RETURNS BOOLEAN AS $$
DECLARE
    query_str  TEXT;
    object_str TEXT;
    count      INT DEFAULT 0;
    user_oid   OID DEFAULT 0;
    object_oid OID DEFAULT 0;
    namespace  OID DEFAULT 0;
BEGIN

    IF user_name IS NOT NULL THEN
        SELECT usesysid INTO user_oid FROM sys_user WHERE usename = user_name;
    END IF;

    IF object_kind IS NOT NULL AND
       schema_name IS NOT NULL AND
       object_name IS NOT NULL THEN

        SELECT oid INTO namespace FROM sys_namespace WHERE nspname = schema_name AND nspparent = 0;

        CASE object_kind
        WHEN 'TABLE' THEN
            SELECT oid INTO object_oid FROM sys_class WHERE relname = object_name AND relnamespace = namespace AND relkind = 'r';
        WHEN 'VIEW' THEN
            SELECT oid INTO object_oid FROM sys_class WHERE relname = object_name AND relnamespace = namespace AND (relkind = 'v' OR relkind = 'm');
        WHEN 'SEQUENCE' THEN
            SELECT oid INTO object_oid FROM sys_class WHERE relname = object_name AND relnamespace = namespace AND relkind = 'S';
        WHEN 'FUNCTION' THEN
            SELECT oid INTO object_oid FROM sys_proc WHERE proname = object_name AND pronamespace = namespace AND protype = 'f';
        WHEN 'PROCEDURE' THEN
            SELECT oid INTO object_oid FROM sys_proc WHERE proname = object_name AND pronamespace = namespace AND protype = 'p';
        WHEN 'PACKAGE' THEN
            SELECT oid INTO object_oid FROM sys_package WHERE pkgname = object_name AND pkgnamespace = namespace;
        END CASE;
    END IF;

    IF is_set THEN
        object_str := object_oid;
    ELSE
        object_str := '-' || object_oid;
    END IF;

    query_str := ' SET SYSAUDIT_RULE TO ''' || user_oid || ', ' || object_str || ', '|| audit_kind || ', ' || audit_event || ', ' || audit_type || ''';';
    EXECUTE query_str;

    RETURN TRUE;

EXCEPTION
    WHEN no_data_found THEN
        RETURN FALSE;

    WHEN invalid_parameter_value THEN
        RAISE WARNING 'invalid AUDIT_TYPE value : ''%'', set failed;', audit_type;
        RETURN FALSE;

    WHEN undefined_object THEN
        RETURN FALSE;
END;
$$ LANGUAGE plsql;

CREATE FUNCTION sysaudit.set_audit_stmt_internal(
    audit_type    VARCHAR(30),
    user_name     VARCHAR(128),
    audit_kind    VARCHAR(10),
    audit_event   VARCHAR(10)
    )RETURNS BOOLEAN AS $$
BEGIN
    RETURN sysaudit.set_audit_rule(audit_type, user_name, audit_kind, NULL, NULL, NULL, audit_event, TRUE);
END;
$$ LANGUAGE plsql;

CREATE FUNCTION sysaudit.set_audit_stmt(
    audit_type    VARCHAR(30),
    user_name     VARCHAR(128),
    audit_kind    VARCHAR(10),
    audit_event   VARCHAR(10)
    )RETURNS BOOLEAN AS $$
DECLARE
    query_str  TEXT;
    result     BOOLEAN DEFAULT FALSE;
BEGIN

    audit_type  = UPPER(audit_type);
    audit_kind  = UPPER(audit_kind);
    audit_event = UPPER(audit_event);

    IF user_name = current_user THEN
        RAISE WARNING 'can not set audit rules for self, set failed;';
        RETURN FALSE;
    END IF;

    result := sysaudit.check_audit_rule(audit_type, user_name, audit_kind, NULL, NULL, NULL, audit_event);

    IF NOT result THEN
        RETURN result;
    END IF;

    result := sysaudit.set_audit_stmt_internal(audit_type, current_user, audit_kind, audit_event);

    IF result THEN
        query_str := 'CALL SYSAUDIT.SET_AUDIT_STMT_INTERNAL(''' || audit_type || ''', ''' || current_user || ''', ''' || audit_kind || ''', ''' || audit_event || ''');';

        INSERT INTO sysaudit.sysaudit_rule VALUES (user_name, query_str, current_user);

        query_str := 'SYSAUDIT.SET_AUDIT_STMT(''' || audit_type || ''', ''' || user_name || ''', ''' || audit_kind || ''', ''' || audit_event || ''');';

        INSERT INTO sysaudit.sysaudit_setting VALUES (current_user, query_str, now());
    END IF;

    RETURN result;
END;
$$ LANGUAGE plsql;

CREATE FUNCTION sysaudit.cancel_audit_stmt_internal(
    audit_type    VARCHAR(30),
    user_name     VARCHAR(128),
    audit_kind    VARCHAR(10),
    audit_event   VARCHAR(10)
    )RETURNS BOOLEAN AS $$
BEGIN
    RETURN sysaudit.set_audit_rule(audit_type, user_name, audit_kind, NULL, NULL, NULL, audit_event, FALSE);
END;
$$ LANGUAGE plsql;

CREATE FUNCTION sysaudit.cancel_audit_stmt(
    audit_type    VARCHAR(30),
    user_name     VARCHAR(128),
    audit_kind    VARCHAR(10),
    audit_event   VARCHAR(10)
    )RETURNS BOOLEAN AS $$
DECLARE
    query_str  TEXT;
    result     BOOLEAN DEFAULT FALSE;
BEGIN

    audit_type  = UPPER(audit_type);
    audit_kind  = UPPER(audit_kind);
    audit_event = UPPER(audit_event);

    IF user_name = current_user THEN
        RAISE WARNING 'can not set audit rules for self, set failed;';
        RETURN FALSE;
    END IF;

    result := sysaudit.check_audit_rule(audit_type, user_name, audit_kind, NULL, NULL, NULL, audit_event);

    IF NOT result THEN
        RETURN result;
    END IF;

    result := sysaudit.cancel_audit_stmt_internal(audit_type, current_user, audit_kind, audit_event);

    IF result THEN
        query_str := 'CALL SYSAUDIT.CANCEL_AUDIT_STMT_INTERNAL(''' || audit_type || ''', ''' || current_user || ''', ''' || audit_kind || ''', ''' || audit_event || ''');';

        INSERT INTO sysaudit.sysaudit_rule VALUES (user_name, query_str, current_user);

        query_str := 'SYSAUDIT.CANCEL_AUDIT_STMT(''' || audit_type || ''', ''' || user_name || ''', ''' || audit_kind || ''', ''' || audit_event || ''');';

        INSERT INTO sysaudit.sysaudit_setting VALUES (current_user, query_str, now());
    END IF;

    RETURN result;
END;
$$ LANGUAGE plsql;

CREATE FUNCTION sysaudit.set_audit_object_internal(
    audit_type    VARCHAR(30),
    user_name     VARCHAR(128),
    audit_kind    VARCHAR(10),
    object_kind   VARCHAR(10),
    schema_name   VARCHAR(128),
    object_name   VARCHAR(128),
    audit_event   VARCHAR(10)
    )RETURNS BOOLEAN AS $$
DECLARE
    result     BOOLEAN;
BEGIN

    result := sysaudit.set_audit_rule(audit_type, user_name, audit_kind, object_kind, schema_name, object_name, audit_event, TRUE);

    RETURN result;
END;
$$ LANGUAGE plsql;

CREATE FUNCTION sysaudit.set_audit_object(
    audit_type    VARCHAR(30),
    user_name     VARCHAR(128),
    audit_kind    VARCHAR(10),
    object_kind   VARCHAR(10),
    schema_name   VARCHAR(128),
    object_name   VARCHAR(128),
    audit_event   VARCHAR(10)
    )RETURNS BOOLEAN AS $$
DECLARE
    query_str  TEXT;
    result     BOOLEAN;
BEGIN

    audit_type  = UPPER(audit_type);
    audit_kind  = UPPER(audit_kind);
    audit_event = UPPER(audit_event);
    object_kind = UPPER(object_kind);

    IF object_kind IS NULL THEN
        RAISE WARNING 'OBJECT_KIND values are not allowed to be NULL, set failed.';
        RETURN FALSE;
    END IF;

    IF schema_name  IS NULL THEN
        RAISE WARNING 'SCHEMA_NAME values are not allowed to be NULL, set failed.';
        RETURN FALSE;
    END IF;

    IF object_name IS NULL THEN
        RAISE WARNING 'OBJECT_NAME values are not allowed to be NULL, set failed.';
        RETURN FALSE;
    END IF;

    IF user_name = current_user THEN
        RAISE WARNING 'can not set audit rules for self, set failed;';
        RETURN FALSE;
    END IF;

    result := sysaudit.check_audit_rule(audit_type, user_name, audit_kind, object_kind, schema_name, object_name, audit_event);

    IF NOT result THEN
        RETURN result;
    END IF;

    result := sysaudit.set_audit_object_internal(audit_type, current_user, audit_kind, object_kind, schema_name, object_name, audit_event);

    IF result THEN
        query_str := 'CALL SYSAUDIT.SET_AUDIT_OBJECT_INTERNAL(''' || audit_type || ''', ''' || current_user || ''', ''' || audit_kind || ''', ''' ||
                                            object_kind || ''', ''' || schema_name || ''', ''' || object_name || ''', ''' || audit_event || ''');';

        INSERT INTO sysaudit.sysaudit_rule VALUES (user_name, query_str, current_user);

        query_str := 'SYSAUDIT.SET_AUDIT_OBJECT(''' || audit_type || ''', ''' || user_name || ''', ''' || audit_kind || ''', ''' ||
                                            object_kind || ''', ''' || schema_name || ''', ''' || object_name || ''', ''' ||audit_event || ''');';

        INSERT INTO sysaudit.sysaudit_setting VALUES (current_user, query_str, now());
    END IF;

    RETURN result;
END;
$$ LANGUAGE plsql;

CREATE FUNCTION sysaudit.cancel_audit_object_internal(
    audit_type    VARCHAR(30),
    user_name     VARCHAR(128),
    audit_kind    VARCHAR(10),
    object_kind   VARCHAR(10),
    schema_name   VARCHAR(128),
    object_name   VARCHAR(128),
    audit_event   VARCHAR(10)
    )RETURNS BOOLEAN AS $$
DECLARE
    result     BOOLEAN;
BEGIN
    result := sysaudit.set_audit_rule(audit_type, user_name, audit_kind, object_kind, schema_name, object_name, audit_event, FALSE);

    RETURN result;
END;
$$ LANGUAGE plsql;

CREATE FUNCTION sysaudit.cancel_audit_object(
    audit_type    VARCHAR(30),
    user_name     VARCHAR(128),
    audit_kind    VARCHAR(10),
    object_kind   VARCHAR(10),
    schema_name   VARCHAR(128),
    object_name   VARCHAR(128),
    audit_event   VARCHAR(10)
    )RETURNS BOOLEAN AS $$
DECLARE
    query_str  TEXT;
    result     BOOLEAN;
BEGIN

    audit_type  = UPPER(audit_type);
    audit_kind  = UPPER(audit_kind);
    audit_event = UPPER(audit_event);
    object_kind = UPPER(object_kind);

    IF object_kind IS NULL THEN
        RAISE WARNING 'OBJECT_KIND values are not allowed to be NULL, set failed.';
        RETURN FALSE;
    END IF;

    IF schema_name  IS NULL THEN
        RAISE WARNING 'SCHEMA_NAME values are not allowed to be NULL, set failed.';
        RETURN FALSE;
    END IF;

    IF object_name IS NULL THEN
        RAISE WARNING 'OBJECT_NAME values are not allowed to be NULL, set failed.';
        RETURN FALSE;
    END IF;

    IF user_name = current_user THEN
        RAISE WARNING 'can not set audit rules for self, set failed;';
        RETURN FALSE;
    END IF;

    result := sysaudit.check_audit_rule(audit_type, user_name, audit_kind, object_kind, schema_name, object_name, audit_event);

    IF NOT result THEN
        RETURN result;
    END IF;

    result := sysaudit.cancel_audit_object_internal(audit_type, current_user, audit_kind, object_kind, schema_name, object_name, audit_event);

    IF result THEN
        query_str := 'CALL SYSAUDIT.CANCEL_AUDIT_OBJECT_INTERNAL(''' || audit_type || ''', ''' || current_user || ''', ''' || audit_kind || ''', ''' ||
                                                object_kind || ''', ''' || schema_name || ''', ''' || object_name || ''', ''' ||audit_event || ''');';

        INSERT INTO sysaudit.sysaudit_rule VALUES (user_name, query_str, current_user);

        query_str := 'SYSAUDIT.CANCEL_AUDIT_OBJECT(''' || audit_type || ''', ''' || user_name || ''', ''' || audit_kind || ''', ''' ||
                                                object_kind || ''', ''' || schema_name || ''', ''' || object_name || ''', ''' ||audit_event || ''');';

        INSERT INTO sysaudit.sysaudit_setting VALUES (current_user, query_str, now());
    END IF;

    RETURN result;
END;
$$ LANGUAGE plsql;

CREATE SERVER sysaudit_fdw_server FOREIGN DATA WRAPPER file_fdw;

CREATE FOREIGN TABLE sysaudit.sysaudit_record (
    serial_num    INT,
    sub_serial    INT,
    audit_type    VARCHAR,
    user_id       OID,
    user_name     VARCHAR,
    ip            VARCHAR,
    database_id   OID,
    database_name VARCHAR,
    schema_id     OID,
    schema_name   VARCHAR,
    object_id     OID,
    object_name   VARCHAR,
    object_type   VARCHAR,
    sql_text      TEXT,
    parameter     TEXT,
    optime        TEXT,
    status        VARCHAR
) SERVER sysaudit_fdw_server
OPTIONS (format 'csv', header 'false', file_path '$audit_log_directory$', encrypt_algorithm '$audit_encrypt_algorithm$', encrypt_key '$audit_encrypt_key$', delimiter ',', null'');

CREATE VIEW sysaudit.sysaudit_records AS
    SELECT
        serial_num,
        sub_serial,
        audit_type,
        user_id,
        user_name,
        ip,
        database_id,
        database_name,
        schema_id,
        schema_name,
        object_id,
        object_name,
        object_type,
        sql_text,
        parameter,
        optime,
        status
    FROM sysaudit.sysaudit_record;

CREATE TABLE IF NOT EXISTS sysaudit.sysaudit_ids_rules
(
    RULENAME    VARCHAR(128),
    ACTIONNAME  VARCHAR(128),
    USERNAME    VARCHAR(128),
    SCHNAME     VARCHAR(128),
    OBJNAME     VARCHAR(128),
    WHENEVER    VARCHAR(20),
    LEGAL_IP    VARCHAR(1024),
    LEGAL_TIME  VARCHAR(1024),
    INTERVAL    INTEGER,
    TIMES       INT,
    PRIMARY KEY (RULENAME)
);

CREATE TABLE IF NOT EXISTS sysaudit.sysaudit_ids_log
(
    RULENAME     VARCHAR(128),
    ACTIONNAME   VARCHAR(128),
    OPTIME       TIMESTAMPTZ,
    USERNAME     VARCHAR,
    IP           VARCHAR,
    REASON       VARCHAR,
    SQL_TEXT     TEXT,
    PRIMARY KEY (RULENAME, OPTIME)
);

GRANT ALL PRIVILEGES ON SCHEMA SYSAUDIT TO PUBLIC;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA SYSAUDIT TO PUBLIC;

DROP USER IF EXISTS IDS_USER;
CREATE USER IDS_USER WITH PASSWORD 'ids_kb_123';

CREATE OR REPLACE FUNCTION add_ids_rule(
    RULENAME       VARCHAR(128),
    ACTIONNAME     VARCHAR(128),
    USERNAME       VARCHAR(128),
    SCHNAME        VARCHAR(128),
    OBJNAME        VARCHAR(128),
    WHEN_EVER      VARCHAR(20),
    LEGAL_IP       VARCHAR(1024),
    LEGAL_TIME     VARCHAR(1024),
    INTERVAL_TIME  INTEGER,
    TIMES          INT
) RETURNS VOID
AS $$
DECLARE
    all_ips   cidr[];
    ip        VARCHAR;
    new_ips   VARCHAR = NULL;

    time_array VARCHAR[];
    time_str   VARCHAR;
    sub_time_array VARCHAR[];
BEGIN
    FOREACH ip in ARRAY string_to_array(LEGAL_IP, ',') LOOP
        BEGIN
            ip = trim(replace(ip, '"', ''));
            PERFORM ip::cidr;
            EXCEPTION
                WHEN others THEN
            BEGIN
                RAISE EXCEPTION 'ERROR DATA FROMAT OF LEGAL_IP: %', ip;
            END;
        END;

        IF new_ips IS NULL THEN
            new_ips = ip;
        ELSE
            new_ips = concat(new_ips, ',', ip);
        END IF;
    END LOOP;

    FOREACH time_str in ARRAY string_to_array(LEGAL_TIME, ',') LOOP
        sub_time_array = string_to_array(time_str, 'TO');
        IF array_length(sub_time_array, 1) <> 2 THEN
            RAISE EXCEPTION 'ERROR DATA FROMAT OF LEGAL_TIME: %', time_str;
        END IF;

        DECLARE
            colon_pos INT;
        BEGIN
            sub_time_array[1] = trim(sub_time_array[1]);
            colon_pos = strpos(sub_time_array[1], ':');

            -- just as 'Tus 08:00'
            IF substring(sub_time_array[1] from 0 for 3)~'^([0-9]+)' = FALSE THEN
                PERFORM to_timestamp(sub_time_array[1], 'Dy HH24:MI:SS');
            ELSIF colon_pos = 2 OR colon_pos = 3 THEN
                PERFORM sub_time_array[1]::time;
            ELSE
                PERFORM sub_time_array[1]::timestamp;
            END IF;

            sub_time_array[2] = trim(sub_time_array[2]);
            colon_pos = strpos(sub_time_array[2], ':');
            IF substring(sub_time_array[2] from 0 for 3)~'^([0-9]+)' = FALSE THEN
                to_timestamp(sub_time_array[2], 'Dy HH24:MI:SS');
            ELSIF colon_pos = 2 OR colon_pos = 3 THEN
                PERFORM sub_time_array[2]::time;
            ELSE
                PERFORM sub_time_array[2]::timestamp;
            END IF;
        EXCEPTION
            WHEN others THEN
            BEGIN
                RAISE EXCEPTION 'ERROR DATA FROMAT OF LEGAL_TIME: %', time_str;
            END;
        END;
    END LOOP;

    insert into sysaudit.sysaudit_ids_rules values(RULENAME, ACTIONNAME, USERNAME, SCHNAME,
        OBJNAME, WHEN_EVER, new_ips, LEGAL_TIME, INTERVAL_TIME, TIMES);
END $$LANGUAGE plsql;

CREATE OR REPLACE FUNCTION del_ids_rule_by_username(USER_NAME VARCHAR(128))
RETURNS VOID AS
   $$ delete from SYSAUDIT.SYSAUDIT_IDS_RULES where USERNAME = $1 $$
LANGUAGE SQL;

CREATE OR REPLACE FUNCTION del_ids_rule_by_rulename(RULE_NAME VARCHAR(128))
RETURNS VOID AS
   $$ delete from SYSAUDIT.SYSAUDIT_IDS_RULES where RULENAME = $1 $$
LANGUAGE SQL;


CREATE OR REPLACE FUNCTION clean_ids_rule() 
RETURNS VOID AS
   $$ delete from sysaudit.sysaudit_ids_rules $$
LANGUAGE SQL;

CREATE OR REPLACE FUNCTION del_ids_log_by_username(USER_NAME  VARCHAR(128))
RETURNS VOID AS
   $$ delete from sysaudit.sysaudit_ids_log where USERNAME = $1 $$
LANGUAGE SQL;

CREATE OR REPLACE FUNCTION del_ids_log_before_days(days INT)
RETURNS VOID AS
   $$ delete from sysaudit.sysaudit_ids_log where OPTIME < (now() - $1); $$
LANGUAGE SQL;

CREATE OR REPLACE FUNCTION clean_ids_log() 
RETURNS VOID AS
   $$ delete from sysaudit.sysaudit_ids_log $$
LANGUAGE SQL;

/* KingbaseES_END */
