--create functions

--datetime functions
CREATE INTERNAL FUNCTION sys_catalog.ADD_MONTHS(day timestamp, val numeric)
RETURNS timestamp
AS 'MODULE_PATHNAME','timestamp_add_months'
LANGUAGE C IMMUTABLE STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.ADD_MONTHS(day timestamptz, val numeric)
--RETURNS timestamp
--AS $$ select ADD_MONTHS(cast($1 as timestamp), val);
--$$ LANGUAGE SQL IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.LAST_DAY(day timestamp)
RETURNS timestamp
AS 'MODULE_PATHNAME','timestamp_last_day'
LANGUAGE C IMMUTABLE STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.LAST_DAY(day timestamptz)
--RETURNS timestamp
--AS $$ select LAST_DAY(cast($1 as timestamp));
--$$ LANGUAGE SQL IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.NEXT_DAY(day timestamp, weekday text)
RETURNS timestamp
AS 'MODULE_PATHNAME','timestamp_next_day'
LANGUAGE C IMMUTABLE STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.NEXT_DAY(day timestamptz, weekday text)
--RETURNS timestamp
--AS $$ select NEXT_DAY(cast($1 as timestamp), weekday);
--$$ LANGUAGE SQL IMMUTABLE STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.ADD_MONTHS(day date, value numeric)
--RETURNS date
--AS 'MODULE_PATHNAME','date_add_months'
--LANGUAGE C IMMUTABLE STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.NEXT_DAY(value date, weekday text)
--RETURNS date
--AS 'MODULE_PATHNAME','date_next_day'
--LANGUAGE C IMMUTABLE STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.LAST_DAY(value date)
--RETURNS date
--AS 'MODULE_PATHNAME','date_last_day'
--LANGUAGE C IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.TIMESUB(head timestamptz, tail timestamptz)
RETURNS float8
AS 'MODULE_PATHNAME', 'timesub'
LANGUAGE C IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.TIMEZONE(value timestamp)
RETURNS timestamptz
AS 'MODULE_PATHNAME','timestamp_localzone'
LANGUAGE C IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.TIMEZONE(value timestamptz)
RETURNS timestamptz
AS 'MODULE_PATHNAME','timestamptz_localzone'
LANGUAGE C IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.TIMEZONE(value timetz)
RETURNS timetz
AS 'MODULE_PATHNAME','timetz_localzone'
LANGUAGE C IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.MONTHS_BETWEEN(timestamp, timestamp)
 returns float STABLE language sql as $$
  select (extract(years from $1)::int * 12 - extract(years from $2)::int * 12)::float +
  (extract(month from $1)::int - extract(month from $2)::int)::float +
  (extract(day from $1)::int - extract(day from $2)::int)/31::float
$$;
